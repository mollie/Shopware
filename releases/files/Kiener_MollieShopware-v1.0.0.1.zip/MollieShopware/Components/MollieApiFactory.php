<?php

namespace MollieShopware\Components;

use Mollie_API_Client;

class MollieApiFactory
{
    /**
     * @var \MollieShopware\Components\Config
     */
    protected $config;

    /**
     * @var Mollie_API_Client
     */
    protected $mollieApi;

    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    public function create()
    {
        if (empty($this->mollieApi)) {
            $apiKey = $this->config->apikey();

            $this->mollieApi = new Mollie_API_Client;
            $this->mollieApi->setApiKey($apiKey);
        }

        return $this->mollieApi;
    }
}
