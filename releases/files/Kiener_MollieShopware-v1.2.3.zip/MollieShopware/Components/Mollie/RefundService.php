<?php

	// Mollie Shopware Plugin Version: 1.2.3

namespace MollieShopware\Components\Mollie;

    class RefundService{

        public function __construct()
        {

            
        }

    }
