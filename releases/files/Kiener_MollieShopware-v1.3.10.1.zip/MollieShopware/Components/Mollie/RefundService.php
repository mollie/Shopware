<?php

	// Mollie Shopware Plugin Version: 1.3.10.1

namespace MollieShopware\Components\Mollie;

    class RefundService{

        public function __construct()
        {

            
        }

    }
