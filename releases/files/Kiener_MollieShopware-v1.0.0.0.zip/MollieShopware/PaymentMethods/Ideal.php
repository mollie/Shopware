<?php

namespace kienerMollie\PaymentMethods;

use Mollie_API_Object_Method;
use Mollie_API_Client;
use kienerMollie\Components\CurrentCustomer;
use Shopware\Components\Model\ModelManager;

class Ideal
{
    /**
     * @var Mollie_API_Client
     */
    protected $mollieApi;

    /**
     * @var CurrentCustomer
     */
    protected $customer;

    /**
     * @var \Shopware\Components\Model\ModelManager
     */
    protected $em;

    public function __construct(Mollie_API_Client $mollieApi, CurrentCustomer $customer, ModelManager $em)
    {
        $this->mollieApi = $mollieApi;
        $this->customer = $customer;
        $this->em = $em;
    }

    public function getIssuers()
    {
        $issuers = $this->mollieApi->issuers->all();

        $idealIssuers = [];

        foreach ($issuers as $key => $issuer) {
            if ($issuer->method === Mollie_API_Object_Method::IDEAL) {

                if ($issuer->id === $this->getSelectedIssuer()) {
                    $issuer->isSelected = true;
                }

                $idealIssuers[] = $issuer;
            }
        }

        return $idealIssuers;
    }

    /**
     * Set the id of the chosen ideal issuer in the database
     */
    public function setSelectedIssuer($issuer)
    {
        $customer = $this->customer->getCurrent();

        if (empty($customer)) {
            return;
        }

        $attributes = $customer->getAttribute();

        if (empty($attributes)) {
            return;
        }

        $attributes->setKienerMollieIdealIssuer($issuer);

        $this->em->persist($attributes);
        $this->em->flush();

        return $issuer;
    }

    /**
     * Get the id of the chosen ideal issuer from database
     */
    public function getSelectedIssuer()
    {
        $customer = $this->customer->getCurrent();

        if (empty($customer)) {
            return '';
        }

        $attributes = $customer->getAttribute();

        if (!empty($attributes)) {
            return $attributes->getKienerMollieIdealIssuer();
        }

        /**
         * In B2b a contact customer doesn't have attributes,
         * so take the attributes of the debtor user it belongs to
         */
        $issuer = $this->em->getConnection()->fetchColumn('
            SELECT s_user_attributes.kiener_mollie_ideal_issuer FROM s_user
            JOIN s_user_attributes ON (s_user.id = s_user_attributes.userID)
            WHERE s_user.customernumber = ?
            AND s_user_attributes.kiener_mollie_ideal_issuer IS NOT NULL
            LIMIT 1
        ', [ $customer->getNumber() ]);

        return empty($issuer) ? '' : $issuer;
    }
}
