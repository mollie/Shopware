<?php

    // Mollie Shopware Plugin Version: 1.3.2

namespace MollieShopware\Components\Mollie;

    class RefundService{

        public function __construct()
        {

            
        }

    }
